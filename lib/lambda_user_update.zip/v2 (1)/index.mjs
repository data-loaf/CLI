import pkg from "pg";
const { Client } = pkg;

const mergeUserData = (currData, newData) => {
  const mergedData = { ...currData };

  for (const prop in newData) {
    mergedData[prop] = newData[prop];
  }

  return mergedData;
};

// TODO: change to using environment variable
const CONNECTION = {
  connectionString: process.env.REDSHIFT_CONN_STRING,
};

const queryRedshift = async (statement, ...parameters) => {
  const client = new Client(CONNECTION);

  await client.connect();
  const result = await client.query(statement, parameters);
  await client.end();

  return result;
};

const getUserDataFromRedshift = async (userId) => {
  const GET_USER = "SELECT * FROM users WHERE user_id = $1";
  const result = await queryRedshift(GET_USER, userId);
  return result.rows[0];
};

const sendUserDataToRedshift = async (userId, data) => {
  const UPDATE_USER = "UPDATE users SET user_attributes = JSON_PARSE($2) WHERE user_id = $1";
  const result = await queryRedshift(UPDATE_USER, userId, data);
  return result;
};

const handler = async (event) => {
  if (!event.body) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "Request body is missing" }),
    };
  }

  try {
    const requestBody = JSON.parse(event.body);
    // const requestBody = event.body;
    const userId = requestBody.user_id;
    const newUserAttrs = requestBody.user_attributes;
    const currentUserData = await getUserDataFromRedshift(userId);
    const currentUserAttrs = JSON.parse(currentUserData.user_attributes);
    const mergedData = mergeUserData(currentUserAttrs, newUserAttrs);
    const result = await sendUserDataToRedshift(userId, mergedData);

    return {
      statusCode: 200,
      body: `User data updated in Redshift database. \nData: ${JSON.stringify({ requestBody, currentUserAttrs, newUserAttrs, mergedData })} \nResponse: ${JSON.stringify(result)}`,
    };
  } catch (error) {
    console.error("Error:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: `Error sending new user data to Redshift: ${error.message} `,
      }),
    };
  }
}

export { handler };